﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lib.LispLang;

namespace Lib.AI
{
	class DeltaMan : Api
	{
		public static string code
		{
			get
			{
				return CompileWithLibs(



					);
			}


		}

	}
}
