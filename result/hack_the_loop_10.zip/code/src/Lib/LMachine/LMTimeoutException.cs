using System;

namespace Lib.LMachine
{
	public class LMTimeoutException : Exception
	{
	}
}