namespace Lib.LMachine
{
	public enum LTag
	{
		Int,
		Pair,
		Closure
	}
}