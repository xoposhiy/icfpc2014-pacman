namespace Lib.LMachine
{
	public enum CTag
	{
		Join,
		Ret,
		Frame,
	}
}