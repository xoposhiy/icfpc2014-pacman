namespace Lib
{
	public static class KnownPlace
	{
		public const string Root = @"..\..\..\..\";
		public const string GccSamples = Root + "gcc-samples\\";
		public const string Ghosts = Root + "ghosts\\";
		public const string Mazes = Root + "mazes\\";

	}
}