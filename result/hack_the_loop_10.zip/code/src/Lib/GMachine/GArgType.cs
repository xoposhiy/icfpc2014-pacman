namespace Lib.GMachine
{
	public enum GArgType
	{
		Const,
		Data,
		Reg,
		IndirectReg,
	}
}